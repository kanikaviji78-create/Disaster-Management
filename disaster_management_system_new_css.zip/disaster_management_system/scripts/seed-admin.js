require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
(async () => {
  const db = await mysql.createConnection({host:process.env.DB_HOST||'localhost',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',database:process.env.DB_NAME||'disaster_db'});
  const hash = await bcrypt.hash('Admin@123', 10);
  await db.execute('INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE role=VALUES(role)', ['System Admin','admin@disaster.local','9000000000',hash,'admin']);
  console.log('Admin ready: admin@disaster.local / Admin@123');
  await db.end();
})().catch(e=>{console.error(e.message);process.exit(1)});
